"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { X, Menu } from "lucide-react"

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const pathname = usePathname()

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen)
  }

  const isActive = (path: string) => {
    return pathname === path
  }

  return (
    <header className="sticky top-0 z-50 w-full bg-white/80 backdrop-blur-sm border-b">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <Image src="/images/talentai-logo.png" alt="TalentAI Logo" width={150} height={50} className="h-10 w-auto" />
        </Link>
        <nav className="hidden md:flex gap-6">
          <Link
            href="/"
            className={`text-sm font-medium ${isActive("/") ? "text-cyan-600" : "text-gray-700 hover:text-cyan-600"} transition-colors`}
          >
            Accueil
          </Link>
          <Link
            href="/solution"
            className={`text-sm font-medium ${isActive("/solution") ? "text-cyan-600" : "text-gray-700 hover:text-cyan-600"} transition-colors`}
          >
            Solution
          </Link>
          <Link
            href="/cas-etudes"
            className={`text-sm font-medium ${isActive("/cas-etudes") ? "text-cyan-600" : "text-gray-700 hover:text-cyan-600"} transition-colors`}
          >
            Cas d'études
          </Link>
          <Link
            href="/equipe"
            className={`text-sm font-medium ${isActive("/equipe") ? "text-cyan-600" : "text-gray-700 hover:text-cyan-600"} transition-colors`}
          >
            Équipe
          </Link>
          <Link
            href="/contact"
            className={`text-sm font-medium ${isActive("/contact") ? "text-cyan-600" : "text-gray-700 hover:text-cyan-600"} transition-colors`}
          >
            Contact
          </Link>
        </nav>
        <Link
          href="/contact"
          className="hidden md:inline-flex h-10 items-center justify-center rounded-md bg-[#0e3b5e] px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-[#0e3b5e]/90 focus:outline-none focus:ring-2 focus:ring-[#0e3b5e] focus:ring-offset-2"
        >
          Nous contacter
        </Link>
        <button className="md:hidden p-2" onClick={toggleMobileMenu}>
          {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 top-16 bg-white z-50 p-4">
          <nav className="flex flex-col gap-4">
            <Link
              href="/"
              className={`text-lg font-medium ${isActive("/") ? "text-cyan-600" : "text-gray-700"} py-2`}
              onClick={toggleMobileMenu}
            >
              Accueil
            </Link>
            <Link
              href="/solution"
              className={`text-lg font-medium ${isActive("/solution") ? "text-cyan-600" : "text-gray-700"} py-2`}
              onClick={toggleMobileMenu}
            >
              Solution
            </Link>
            <Link
              href="/cas-etudes"
              className={`text-lg font-medium ${isActive("/cas-etudes") ? "text-cyan-600" : "text-gray-700"} py-2`}
              onClick={toggleMobileMenu}
            >
              Cas d'études
            </Link>
            <Link
              href="/equipe"
              className={`text-lg font-medium ${isActive("/equipe") ? "text-cyan-600" : "text-gray-700"} py-2`}
              onClick={toggleMobileMenu}
            >
              Équipe
            </Link>
            <Link
              href="/contact"
              className={`text-lg font-medium ${isActive("/contact") ? "text-cyan-600" : "text-gray-700"} py-2`}
              onClick={toggleMobileMenu}
            >
              Contact
            </Link>
            <Link
              href="/contact"
              className="mt-4 w-full inline-flex h-12 items-center justify-center rounded-md bg-[#0e3b5e] px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-[#0e3b5e]/90"
              onClick={toggleMobileMenu}
            >
              Nous contacter
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}
