import Image from "next/image"

interface TeamMemberProps {
  image: string
  name: string
  role: string
  bio: string
}

export default function TeamMember({ image, name, role, bio }: TeamMemberProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow text-center">
      <div className="relative h-32 w-32 mx-auto mb-4 rounded-full overflow-hidden">
        <Image src={image || "/placeholder.svg"} alt={name} fill className="object-cover" />
      </div>
      <h3 className="text-xl font-semibold text-[#0e3b5e]">{name}</h3>
      <p className="text-cyan-600 font-medium mb-2">{role}</p>
      <p className="text-gray-600">{bio}</p>
    </div>
  )
}
