import Image from "next/image"
import Link from "next/link"
import { Linkedin, Instagram } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-[#0e3b5e] text-white py-12">
      <div className="container">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <Image
              src="/images/talentai-logo-white.png"
              alt="TalentAI Logo"
              width={150}
              height={50}
              className="h-10 w-auto mb-4"
            />
            <p className="text-white/80 max-w-md">
              TalentAI révolutionne le recrutement grâce à l'intelligence artificielle. Notre solution PlurineurAI
              permet de trouver les meilleurs talents sans biais.
            </p>
          </div>
          <div>
            <h3 className="font-medium text-lg mb-4">Liens rapides</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-white/80 hover:text-white transition-colors">
                  Accueil
                </Link>
              </li>
              <li>
                <Link href="/solution" className="text-white/80 hover:text-white transition-colors">
                  Solution
                </Link>
              </li>
              <li>
                <Link href="/cas-etudes" className="text-white/80 hover:text-white transition-colors">
                  Cas d'études
                </Link>
              </li>
              <li>
                <Link href="/equipe" className="text-white/80 hover:text-white transition-colors">
                  Équipe
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-white/80 hover:text-white transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-medium text-lg mb-4">Suivez-nous</h3>
            <div className="flex gap-4">
              <a
                href="https://www.linkedin.com/company/talent-ai-2025"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/80 hover:text-white transition-colors"
              >
                <Linkedin className="h-6 w-6" />
              </a>
              <a
                href="https://www.instagram.com/talentai2025/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/80 hover:text-white transition-colors"
              >
                <Instagram className="h-6 w-6" />
              </a>
            </div>
          </div>
        </div>
        <div className="border-t border-white/20 mt-8 pt-8 text-center text-white/60 text-sm">
          <p>© {new Date().getFullYear()} TalentAI. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  )
}
