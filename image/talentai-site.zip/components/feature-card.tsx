import { Brain, Users, BarChart3, Smile } from "lucide-react"

interface FeatureCardProps {
  icon: "matching" | "predictive" | "unbiased" | "experience"
  title: string
  description: string
}

export default function FeatureCard({ icon, title, description }: FeatureCardProps) {
  const getIcon = () => {
    switch (icon) {
      case "matching":
        return <Brain className="h-6 w-6 text-cyan-600" />
      case "predictive":
        return <BarChart3 className="h-6 w-6 text-cyan-600" />
      case "unbiased":
        return <Users className="h-6 w-6 text-cyan-600" />
      case "experience":
        return <Smile className="h-6 w-6 text-cyan-600" />
      default:
        return null
    }
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
      <div className="h-12 w-12 rounded-full bg-cyan-100 flex items-center justify-center mb-4">{getIcon()}</div>
      <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  )
}
