import Image from "next/image"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1">
        {/* Section Accueil */}
        <section className="relative py-20 md:py-32 lg:py-40 overflow-hidden bg-gradient-to-br from-[#0e3b5e] to-[#0e3b5e]/90 min-h-[calc(100vh-64px)]">
          <div className="absolute inset-0 bg-[url('/images/pattern.svg')] opacity-10"></div>
          <div className="container relative grid md:grid-cols-2 gap-8 items-center">
            <div className="text-white space-y-6">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                Recruter plus vite, <span className="text-cyan-400">plus humain</span>
              </h1>
              <p className="text-lg md:text-xl text-white/80 max-w-lg">
                PlurineurAI révolutionne le recrutement grâce à l'intelligence artificielle. Trouvez les meilleurs
                talents sans biais, avec une expérience candidat optimale.
              </p>
              <Link
                href="/solution"
                className="inline-flex items-center gap-2 h-12 px-6 rounded-md bg-cyan-500 text-white font-medium hover:bg-cyan-600 transition-colors"
              >
                Découvrir la solution <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
            <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden shadow-2xl">
              <Image src="/images/hero-image.jpg" alt="PlurineurAI en action" fill className="object-cover" priority />
            </div>
          </div>
        </section>

        {/* Section Avantages */}
        <section className="py-20 bg-gray-50">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-4">Pourquoi choisir TalentAI ?</h2>
              <p className="text-lg text-gray-600">
                Notre solution PlurineurAI transforme votre processus de recrutement grâce à l'intelligence
                artificielle.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="h-12 w-12 rounded-full bg-cyan-100 flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-cyan-600"
                  >
                    <path d="M12 2v4" />
                    <path d="M12 18v4" />
                    <path d="m4.93 4.93 2.83 2.83" />
                    <path d="m16.24 16.24 2.83 2.83" />
                    <path d="M2 12h4" />
                    <path d="M18 12h4" />
                    <path d="m4.93 19.07 2.83-2.83" />
                    <path d="m16.24 7.76 2.83-2.83" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Gain de temps</h3>
                <p className="text-gray-600">
                  Réduisez de 70% le temps consacré au tri des CV et à la présélection des candidats.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="h-12 w-12 rounded-full bg-cyan-100 flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-cyan-600"
                  >
                    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                    <circle cx="9" cy="7" r="4" />
                    <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                    <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Meilleurs recrutements</h3>
                <p className="text-gray-600">
                  Augmentez de 40% la qualité de vos recrutements grâce à notre algorithme de matching avancé.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="h-12 w-12 rounded-full bg-cyan-100 flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-cyan-600"
                  >
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Recrutement éthique</h3>
                <p className="text-gray-600">
                  Éliminez les biais inconscients et favorisez la diversité dans vos équipes.
                </p>
              </div>
            </div>
            <div className="text-center mt-12">
              <Link
                href="/solution"
                className="inline-flex items-center gap-2 h-12 px-6 rounded-md bg-[#0e3b5e] text-white font-medium hover:bg-[#0e3b5e]/90 transition-colors"
              >
                En savoir plus sur notre solution
              </Link>
            </div>
          </div>
        </section>

        {/* Section Témoignages */}
        {/* Section Nos expertises */}
        <section className="py-20">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-4">Nos expertises</h2>
              <p className="text-lg text-gray-600">
                Découvrez comment notre technologie s'adapte à différents secteurs et besoins spécifiques.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-100">
                <div className="h-16 w-16 rounded-full bg-cyan-100 flex items-center justify-center mb-6">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="28"
                    height="28"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-cyan-600"
                  >
                    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                    <circle cx="9" cy="7" r="4" />
                    <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                    <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-3">Recrutement inclusif</h3>
                <p className="text-gray-700 mb-4">
                  Notre IA est conçue pour éliminer les biais inconscients et favoriser la diversité dans vos équipes,
                  garantissant un processus de recrutement équitable pour tous les candidats.
                </p>
              </div>
              <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-100">
                <div className="h-16 w-16 rounded-full bg-cyan-100 flex items-center justify-center mb-6">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="28"
                    height="28"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-cyan-600"
                  >
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                    <circle cx="12" cy="7" r="4" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-3">Analyse prédictive RH</h3>
                <p className="text-gray-700 mb-4">
                  Anticipez les besoins en recrutement, identifiez les risques de turnover et optimisez la gestion des
                  talents grâce à nos modèles prédictifs basés sur l'intelligence artificielle.
                </p>
              </div>
              <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-100">
                <div className="h-16 w-16 rounded-full bg-cyan-100 flex items-center justify-center mb-6">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="28"
                    height="28"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-cyan-600"
                  >
                    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                    <polyline points="14 2 14 8 20 8" />
                    <line x1="16" y1="13" x2="8" y2="13" />
                    <line x1="16" y1="17" x2="8" y2="17" />
                    <line x1="10" y1="9" x2="8" y2="9" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-3">Automatisation des processus</h3>
                <p className="text-gray-700 mb-4">
                  Simplifiez et accélérez vos processus RH grâce à l'automatisation intelligente des tâches répétitives,
                  permettant à vos équipes de se concentrer sur les aspects stratégiques du recrutement.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Section Témoignage Client */}
        <section className="py-20 bg-gray-50">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="relative h-[400px] rounded-lg overflow-hidden shadow-xl">
                <Image src="/images/plurielles-case.jpg" alt="Témoignage client" fill className="object-cover" />
              </div>
              <div>
                <div className="inline-block px-4 py-1 bg-cyan-100 text-cyan-800 rounded-full text-sm font-medium mb-4">
                  Témoignage client
                </div>
                <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-6">Nos clients, nos collaborateurs</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Découvrez comment nos clients transforment leur processus de recrutement grâce à PlurineurAI et
                  deviennent de véritables partenaires dans l'amélioration continue de notre solution.
                </p>
                <ul className="space-y-4 mb-6">
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-cyan-600"
                      >
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Augmentation de 40%</strong> de la diversité des profils
                      recrutés
                    </p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-cyan-600"
                      >
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Réduction de 60%</strong> du temps consacré au tri des CV
                    </p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-cyan-600"
                      >
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Amélioration de 35%</strong> de la satisfaction des candidats
                    </p>
                  </li>
                </ul>
                <div className="p-4 bg-white rounded-lg shadow-md border-l-4 border-cyan-500">
                  <p className="text-gray-700 italic">
                    "PlurineurAI a révolutionné notre façon de recruter. Nous avons non seulement gagné en efficacité,
                    mais aussi en qualité des profils sélectionnés. C'est devenu un outil indispensable pour notre
                    agence."
                  </p>
                  <p className="text-right mt-2 font-medium text-[#0e3b5e]">
                    — Thomas Martin, Directeur d'agence de recrutement
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Section CTA */}
        <section className="py-20 bg-gradient-to-br from-[#0e3b5e] to-[#0e3b5e]/90 text-white">
          <div className="container text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Prêt à révolutionner votre recrutement ?</h2>
            <p className="text-xl text-white/80 max-w-2xl mx-auto mb-8">
              Rejoignez les entreprises qui transforment leur processus RH grâce à l'intelligence artificielle.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/contact"
                className="inline-flex items-center justify-center h-12 px-6 rounded-md bg-cyan-500 text-white font-medium hover:bg-cyan-600 transition-colors"
              >
                Demander une démo
              </Link>
              <Link
                href="/solution"
                className="inline-flex items-center justify-center h-12 px-6 rounded-md bg-white text-[#0e3b5e] font-medium hover:bg-gray-100 transition-colors"
              >
                En savoir plus
              </Link>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}
