import Image from "next/image"
import Link from "next/link"
import { ArrowRight, CheckCircle, Clock, Users, ThumbsUp, Quote } from "lucide-react"

export default function CasEtudes() {
  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-16 md:py-24 bg-gradient-to-br from-[#0e3b5e] to-[#0e3b5e]/90 text-white">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <div className="inline-block px-4 py-1 bg-cyan-500/20 text-cyan-300 rounded-full text-sm font-medium mb-4">
                Cas d'études
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Nos réussites clients</h1>
              <p className="text-xl text-white/80 mb-8">
                Découvrez comment PlurineurAI transforme les processus de recrutement de nos clients
              </p>
            </div>
          </div>
        </section>

        {/* Overview Section */}
        <section className="py-20">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="relative h-[400px] rounded-lg overflow-hidden shadow-xl">
                <Image src="/images/plurielles-case.jpg" alt="Cas d'étude" fill className="object-cover" />
              </div>
              <div>
                <h2 className="text-3xl font-bold text-[#0e3b5e] mb-6">Nos clients et leurs défis</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Nos clients viennent de divers secteurs d'activité, chacun avec ses propres défis en matière de
                  recrutement. Qu'il s'agisse d'entreprises technologiques en forte croissance, d'institutions
                  financières établies ou d'organisations dédiées à la promotion de la diversité, tous cherchent à
                  optimiser leur processus de recrutement.
                </p>
                <div className="bg-gray-50 p-6 rounded-lg border-l-4 border-cyan-500">
                  <h3 className="font-semibold text-[#0e3b5e] mb-2">Profils types de nos clients</h3>
                  <ul className="space-y-2 text-gray-700">
                    <li className="flex items-start gap-2">
                      <span className="text-cyan-600 mt-1">•</span>
                      <span>Startups et scale-ups en forte croissance</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-cyan-600 mt-1">•</span>
                      <span>Entreprises de taille moyenne en transformation digitale</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-cyan-600 mt-1">•</span>
                      <span>Grands groupes cherchant à moderniser leurs processus RH</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-cyan-600 mt-1">•</span>
                      <span>Organisations spécialisées dans la diversité et l'inclusion</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Challenge Section */}
        <section className="py-20 bg-gray-50">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-4">Les défis communs</h2>
              <p className="text-lg text-gray-600">
                Les obstacles fréquemment rencontrés par nos clients dans leurs processus de recrutement
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="h-12 w-12 rounded-full bg-cyan-100 flex items-center justify-center mb-4">
                  <Clock className="h-6 w-6 text-cyan-600" />
                </div>
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Processus chronophage</h3>
                <p className="text-gray-600">
                  Les équipes RH passent un temps considérable à trier manuellement les CV et à présélectionner les
                  candidats, ce qui ralentit considérablement le processus de recrutement.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="h-12 w-12 rounded-full bg-cyan-100 flex items-center justify-center mb-4">
                  <Users className="h-6 w-6 text-cyan-600" />
                </div>
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Biais inconscients</h3>
                <p className="text-gray-600">
                  Malgré leur engagement pour la diversité, les recruteurs sont confrontés à des biais inconscients qui
                  peuvent influencer leurs décisions lors de la sélection des candidats.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="h-12 w-12 rounded-full bg-cyan-100 flex items-center justify-center mb-4">
                  <ThumbsUp className="h-6 w-6 text-cyan-600" />
                </div>
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Expérience candidat</h3>
                <p className="text-gray-600">
                  L'expérience candidat souffre de délais de réponse trop longs et d'un manque de personnalisation dans
                  les interactions, ce qui affecte l'image de marque employeur.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Solution Section */}
        <section className="py-20">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <div className="inline-block px-4 py-1 bg-cyan-100 text-cyan-800 rounded-full text-sm font-medium mb-4">
                  Notre solution
                </div>
                <h2 className="text-3xl font-bold text-[#0e3b5e] mb-6">Implémentation de PlurineurAI</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Après une analyse approfondie des besoins spécifiques de chaque client, notre équipe déploie
                  PlurineurAI pour transformer leur processus de recrutement. La mise en œuvre se déroule généralement
                  en plusieurs étapes clés :
                </p>
                <ul className="space-y-4 mb-6">
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <span className="font-semibold text-cyan-600">1</span>
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Analyse des besoins</strong> et configuration personnalisée de
                      la plateforme pour répondre aux objectifs spécifiques du client.
                    </p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <span className="font-semibold text-cyan-600">2</span>
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Formation de l'équipe RH</strong> à l'utilisation de la
                      plateforme et à l'interprétation des résultats fournis par l'IA.
                    </p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <span className="font-semibold text-cyan-600">3</span>
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Intégration avec les systèmes existants</strong> pour assurer
                      une transition fluide et une adoption rapide par les équipes.
                    </p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <span className="font-semibold text-cyan-600">4</span>
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Mise en place d'un suivi régulier</strong> pour mesurer les
                      résultats et optimiser continuellement la solution.
                    </p>
                  </li>
                </ul>
              </div>
              <div className="relative">
                <div className="absolute -top-4 -left-4 w-full h-full bg-[#0e3b5e]/10 rounded-lg"></div>
                <div className="relative bg-white p-6 rounded-lg shadow-xl border border-gray-200">
                  <h3 className="text-xl font-semibold text-[#0e3b5e] mb-4">Fonctionnalités déployées</h3>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                      <span className="text-gray-700">
                        <strong>Matching de talents</strong> pour identifier les candidats les plus adaptés aux postes
                      </span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                      <span className="text-gray-700">
                        <strong>Analyse prédictive</strong> pour anticiper les besoins en recrutement
                      </span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                      <span className="text-gray-700">
                        <strong>Détection et élimination des biais</strong> dans le processus de sélection
                      </span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                      <span className="text-gray-700">
                        <strong>Automatisation des communications</strong> avec les candidats
                      </span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                      <span className="text-gray-700">
                        <strong>Tableau de bord analytique</strong> pour suivre les KPIs de recrutement
                      </span>
                    </li>
                  </ul>
                  <div className="mt-6 pt-6 border-t border-gray-200">
                    <h4 className="font-medium text-[#0e3b5e] mb-2">Équipe projet</h4>
                    <div className="flex items-center gap-4">
                      <div className="flex -space-x-2">
                        <div className="h-8 w-8 rounded-full bg-cyan-100 flex items-center justify-center border-2 border-white">
                          <span className="text-xs font-medium text-cyan-800">MO</span>
                        </div>
                        <div className="h-8 w-8 rounded-full bg-cyan-100 flex items-center justify-center border-2 border-white">
                          <span className="text-xs font-medium text-cyan-800">GD</span>
                        </div>
                        <div className="h-8 w-8 rounded-full bg-cyan-100 flex items-center justify-center border-2 border-white">
                          <span className="text-xs font-medium text-cyan-800">YK</span>
                        </div>
                        <div className="h-8 w-8 rounded-full bg-cyan-100 flex items-center justify-center border-2 border-white">
                          <span className="text-xs font-medium text-cyan-800">KE</span>
                        </div>
                      </div>
                      <span className="text-sm text-gray-600">Équipe TalentAI</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Results Section */}
        <section className="py-20 bg-gray-50">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-4">Résultats moyens observés</h2>
              <p className="text-lg text-gray-600">
                L'impact mesurable de PlurineurAI sur les processus de recrutement de nos clients
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="bg-white p-8 rounded-lg shadow-md text-center">
                <div className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-cyan-100 mb-4">
                  <span className="text-3xl font-bold text-cyan-600">+40%</span>
                </div>
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Diversité des profils</h3>
                <p className="text-gray-600">
                  Augmentation significative de la diversité des profils recrutés, favorisant l'inclusion et
                  l'innovation.
                </p>
              </div>
              <div className="bg-white p-8 rounded-lg shadow-md text-center">
                <div className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-cyan-100 mb-4">
                  <span className="text-3xl font-bold text-cyan-600">-60%</span>
                </div>
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Temps de tri des CV</h3>
                <p className="text-gray-600">
                  Réduction drastique du temps consacré au tri des CV, permettant aux équipes RH de se concentrer sur
                  des tâches à plus forte valeur ajoutée.
                </p>
              </div>
              <div className="bg-white p-8 rounded-lg shadow-md text-center">
                <div className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-cyan-100 mb-4">
                  <span className="text-3xl font-bold text-cyan-600">+35%</span>
                </div>
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Satisfaction candidats</h3>
                <p className="text-gray-600">
                  Amélioration significative de la satisfaction des candidats grâce à un processus plus fluide et des
                  communications personnalisées.
                </p>
              </div>
            </div>
            <div className="mt-12 max-w-4xl mx-auto">
              <div className="bg-white p-8 rounded-lg shadow-md">
                <div className="flex items-start gap-4">
                  <Quote className="h-10 w-10 text-cyan-500 flex-shrink-0" />
                  <div>
                    <p className="text-lg text-gray-700 italic mb-4">
                      "PlurineurAI nous a permis de révolutionner notre approche du recrutement. Grâce à cette solution,
                      nous avons pu identifier des talents que nous n'aurions jamais découverts avec nos méthodes
                      traditionnelles. Les résultats ont dépassé nos attentes, tant en termes de qualité des
                      recrutements que d'efficacité du processus."
                    </p>
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded-full bg-[#0e3b5e] flex items-center justify-center text-white">
                        <span className="font-medium">DRH</span>
                      </div>
                      <div>
                        <p className="font-semibold text-[#0e3b5e]">Directeur des Ressources Humaines</p>
                        <p className="text-gray-600">Entreprise du secteur de la diversité</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Additional Benefits Section */}
        <section className="py-20">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold text-[#0e3b5e] mb-6">Bénéfices supplémentaires</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Au-delà des résultats quantitatifs, nos clients constatent plusieurs améliorations qualitatives
                  significatives dans leur processus de recrutement et leur culture d'entreprise :
                </p>
                <ul className="space-y-4">
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <CheckCircle className="h-4 w-4 text-cyan-600" />
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Renforcement de l'image de marque employeur</strong> grâce à un
                      processus de recrutement innovant et respectueux des candidats.
                    </p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <CheckCircle className="h-4 w-4 text-cyan-600" />
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Meilleure adéquation entre les candidats et la culture</strong>{" "}
                      d'entreprise, conduisant à une intégration plus rapide et une rétention accrue.
                    </p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <CheckCircle className="h-4 w-4 text-cyan-600" />
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Valorisation des compétences de l'équipe RH</strong> qui peut
                      désormais se concentrer sur des aspects stratégiques plutôt que sur des tâches administratives.
                    </p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <CheckCircle className="h-4 w-4 text-cyan-600" />
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Capacité à identifier des talents atypiques</strong> mais
                      prometteurs qui auraient été écartés par un processus de recrutement traditionnel.
                    </p>
                  </li>
                </ul>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 p-6 rounded-lg">
                  <div className="text-3xl font-bold text-cyan-600 mb-2">94%</div>
                  <p className="text-gray-700">des recrutements validés après période d'essai</p>
                </div>
                <div className="bg-gray-50 p-6 rounded-lg">
                  <div className="text-3xl font-bold text-cyan-600 mb-2">3x</div>
                  <p className="text-gray-700">plus de candidatures spontanées reçues</p>
                </div>
                <div className="bg-gray-50 p-6 rounded-lg">
                  <div className="text-3xl font-bold text-cyan-600 mb-2">45%</div>
                  <p className="text-gray-700">de réduction du coût par recrutement</p>
                </div>
                <div className="bg-gray-50 p-6 rounded-lg">
                  <div className="text-3xl font-bold text-cyan-600 mb-2">2 sem.</div>
                  <p className="text-gray-700">de réduction du délai moyen de recrutement</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Implementation Timeline */}
        <section className="py-20 bg-gray-50">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-4">Chronologie type d'un projet</h2>
              <p className="text-lg text-gray-600">
                De l'identification des besoins à l'obtention de résultats concrets
              </p>
            </div>
            <div className="max-w-4xl mx-auto">
              <div className="relative">
                {/* Vertical line */}
                <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-cyan-200"></div>

                <div className="space-y-12">
                  <div className="relative pl-12">
                    <div className="absolute left-0 top-0 h-8 w-8 rounded-full bg-cyan-500 flex items-center justify-center text-white">
                      <span className="font-medium">1</span>
                    </div>
                    <div className="bg-white p-6 rounded-lg shadow-md">
                      <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Analyse des besoins</h3>
                      <p className="text-gray-600 mb-2">
                        Identification des défis spécifiques du client et définition des objectifs du projet.
                      </p>
                      <p className="text-sm text-gray-500">Semaine 1-2</p>
                    </div>
                  </div>

                  <div className="relative pl-12">
                    <div className="absolute left-0 top-0 h-8 w-8 rounded-full bg-cyan-500 flex items-center justify-center text-white">
                      <span className="font-medium">2</span>
                    </div>
                    <div className="bg-white p-6 rounded-lg shadow-md">
                      <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Configuration et déploiement</h3>
                      <p className="text-gray-600 mb-2">
                        Personnalisation de PlurineurAI selon les besoins spécifiques du client et intégration avec les
                        systèmes existants.
                      </p>
                      <p className="text-sm text-gray-500">Semaine 3-4</p>
                    </div>
                  </div>

                  <div className="relative pl-12">
                    <div className="absolute left-0 top-0 h-8 w-8 rounded-full bg-cyan-500 flex items-center justify-center text-white">
                      <span className="font-medium">3</span>
                    </div>
                    <div className="bg-white p-6 rounded-lg shadow-md">
                      <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Formation et adoption</h3>
                      <p className="text-gray-600 mb-2">
                        Formation de l'équipe RH et accompagnement dans la prise en main de la solution.
                      </p>
                      <p className="text-sm text-gray-500">Semaine 5</p>
                    </div>
                  </div>

                  <div className="relative pl-12">
                    <div className="absolute left-0 top-0 h-8 w-8 rounded-full bg-cyan-500 flex items-center justify-center text-white">
                      <span className="font-medium">4</span>
                    </div>
                    <div className="bg-white p-6 rounded-lg shadow-md">
                      <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Premiers résultats</h3>
                      <p className="text-gray-600 mb-2">
                        Observation des premières améliorations dans le processus de recrutement et ajustements
                        nécessaires.
                      </p>
                      <p className="text-sm text-gray-500">Mois 2-3</p>
                    </div>
                  </div>

                  <div className="relative pl-12">
                    <div className="absolute left-0 top-0 h-8 w-8 rounded-full bg-cyan-500 flex items-center justify-center text-white">
                      <span className="font-medium">5</span>
                    </div>
                    <div className="bg-white p-6 rounded-lg shadow-md">
                      <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Évaluation complète</h3>
                      <p className="text-gray-600 mb-2">
                        Analyse approfondie des résultats et mesure de l'impact sur les KPIs de recrutement.
                      </p>
                      <p className="text-sm text-gray-500">Mois 6</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-br from-[#0e3b5e] to-[#0e3b5e]/90 text-white">
          <div className="container text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Prêt à transformer votre recrutement ?</h2>
            <p className="text-xl text-white/80 max-w-2xl mx-auto mb-8">
              Découvrez comment PlurineurAI peut vous aider à optimiser votre processus de recrutement et à promouvoir
              la diversité au sein de votre entreprise.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/contact"
                className="inline-flex items-center justify-center h-12 px-8 rounded-md bg-cyan-500 text-white font-medium hover:bg-cyan-600 transition-colors"
              >
                Demander une démo
              </Link>
              <Link
                href="/solution"
                className="inline-flex items-center justify-center h-12 px-8 rounded-md bg-white text-[#0e3b5e] font-medium hover:bg-gray-100 transition-colors"
              >
                En savoir plus
              </Link>
            </div>
          </div>
        </section>

        {/* Case Studies Section */}
        <section className="py-20">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-4">Exemples de cas clients</h2>
              <p className="text-lg text-gray-600">
                Découvrez comment différentes entreprises ont transformé leur processus de recrutement avec PlurineurAI
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative h-48">
                  <Image src="/images/case-study-1.jpg" alt="Cas d'étude" fill className="object-cover" />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Secteur technologique</h3>
                  <p className="text-gray-600 mb-4">
                    Comment une entreprise tech a réduit de 50% son temps de recrutement tout en améliorant la qualité
                    des embauches.
                  </p>
                  <Link href="#" className="inline-flex items-center text-cyan-600 hover:text-cyan-700 font-medium">
                    Lire l'étude de cas <ArrowRight className="h-4 w-4 ml-1" />
                  </Link>
                </div>
              </div>
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative h-48">
                  <Image src="/images/case-study-2.jpg" alt="Cas d'étude" fill className="object-cover" />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Secteur financier</h3>
                  <p className="text-gray-600 mb-4">
                    Une institution financière qui a transformé son approche du recrutement pour attirer les meilleurs
                    talents.
                  </p>
                  <Link href="#" className="inline-flex items-center text-cyan-600 hover:text-cyan-700 font-medium">
                    Lire l'étude de cas <ArrowRight className="h-4 w-4 ml-1" />
                  </Link>
                </div>
              </div>
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative h-48">
                  <Image src="/images/case-study-3.jpg" alt="Cas d'étude" fill className="object-cover" />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Secteur de la santé</h3>
                  <p className="text-gray-600 mb-4">
                    Comment un groupe hospitalier a utilisé l'IA pour recruter des profils médicaux spécialisés dans un
                    marché tendu.
                  </p>
                  <Link href="#" className="inline-flex items-center text-cyan-600 hover:text-cyan-700 font-medium">
                    Lire l'étude de cas <ArrowRight className="h-4 w-4 ml-1" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}
