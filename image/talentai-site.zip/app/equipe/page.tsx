import Image from "next/image"
import Link from "next/link"
import TeamMember from "@/components/team-member"

export default function Equipe() {
  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-16 md:py-24 bg-gradient-to-br from-[#0e3b5e] to-[#0e3b5e]/90 text-white">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <div className="text-cyan-400 font-medium mb-2">DÉCOUVREZ LA START-UP</div>
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Notre Équipe</h1>
              <p className="text-xl text-white/80 mb-8">
                OPTIMISER LA GESTION DES TALENTS POUR DES ENTREPRISES PERFORMANTES ET INCLUSIVES
              </p>
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-20">
          <div className="container">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <TeamMember
                image="/images/team-1.jpg"
                name="Morgane Orblin"
                role="Product Owner"
                bio="Experte en gestion de produit avec une vision stratégique pour le développement de PlurineurAI. Morgane assure la cohérence entre les besoins utilisateurs et les fonctionnalités développées."
              />
              <TeamMember
                image="/images/team-2.jpg"
                name="Guillaume DATIL"
                role="Scrum Master Expert immobilier"
                bio="Expert en méthodologies agiles et dans le secteur immobilier, Guillaume facilite la collaboration au sein de l'équipe et apporte sa connaissance approfondie du marché immobilier."
              />
              <TeamMember
                image="/images/team-3.jpg"
                name="Yağmur Koçoğlu"
                role="Expert numérique"
                bio="Spécialiste en technologies numériques et intelligence artificielle, Yağmur contribue au développement des algorithmes avancés qui alimentent notre plateforme."
              />
              <TeamMember
                image="/images/team-4.jpg"
                name="Kenza EL HOUARI"
                role="Expert numérique"
                bio="Experte en transformation digitale et expérience utilisateur, Kenza assure que nos solutions soient à la fois innovantes et accessibles pour tous nos utilisateurs."
              />
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-20 bg-gray-50">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-4">Nos Valeurs</h2>
              <p className="text-lg text-gray-600">
                Les principes qui guident nos actions et notre vision chez TalentAI.
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="h-12 w-12 rounded-full bg-cyan-100 flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-cyan-600"
                  >
                    <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                    <path d="m9 12 2 2 4-4" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Éthique</h3>
                <p className="text-gray-600">
                  Nous développons des technologies responsables qui respectent les principes d'équité et de
                  transparence.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="h-12 w-12 rounded-full bg-cyan-100 flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-cyan-600"
                  >
                    <path d="M12 22v-5" />
                    <path d="M9 7V2" />
                    <path d="M15 7V2" />
                    <path d="M6 13V8a3 3 0 0 1 3-3h6a3 3 0 0 1 3 3v5a3 3 0 0 1-3 3H9a3 3 0 0 1-3-3Z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Innovation</h3>
                <p className="text-gray-600">
                  Nous repoussons constamment les limites de la technologie pour créer des solutions toujours plus
                  performantes.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="h-12 w-12 rounded-full bg-cyan-100 flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-cyan-600"
                  >
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                    <circle cx="9" cy="7" r="4" />
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                    <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Diversité</h3>
                <p className="text-gray-600">
                  Nous croyons en la richesse des différences et nous nous engageons à promouvoir la diversité dans le
                  recrutement.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="h-12 w-12 rounded-full bg-cyan-100 flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-cyan-600"
                  >
                    <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
                    <circle cx="12" cy="12" r="3" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Transparence</h3>
                <p className="text-gray-600">
                  Nous communiquons ouvertement sur notre technologie et nos processus pour établir une relation de
                  confiance.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Story Section */}
        <section className="py-20">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="relative h-[400px] rounded-lg overflow-hidden shadow-xl">
                <Image src="/images/our-story.jpg" alt="Notre histoire" fill className="object-cover" />
              </div>
              <div>
                <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-6">Notre Histoire</h2>
                <p className="text-lg text-gray-600 mb-6">
                  TalentAI est née en 2023 de la rencontre de quatre experts passionnés par l'innovation RH et la
                  technologie. Face aux défis croissants du recrutement et de la gestion des talents, notre équipe a
                  décidé d'unir ses compétences pour créer une solution révolutionnaire.
                </p>
                <p className="text-lg text-gray-600 mb-6">
                  Morgane, Guillaume, Yağmur et Kenza ont combiné leurs expertises complémentaires en product
                  management, méthodologies agiles, technologies numériques et expérience utilisateur pour développer
                  PlurineurAI, une plateforme qui transforme la façon dont les entreprises recrutent et gèrent leurs
                  talents.
                </p>
                <p className="text-lg text-gray-600">
                  Aujourd'hui, notre startup se positionne comme un acteur innovant dans le domaine de la HR Tech, avec
                  une mission claire : optimiser la gestion des talents pour des entreprises plus performantes et
                  inclusives.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Join Us Section */}
        <section className="py-20 bg-gradient-to-br from-[#0e3b5e] to-[#0e3b5e]/90 text-white">
          <div className="container text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Rejoignez l'aventure TalentAI</h2>
            <p className="text-xl text-white/80 max-w-2xl mx-auto mb-8">
              Nous sommes toujours à la recherche de talents passionnés pour rejoindre notre équipe et contribuer à
              notre mission.
            </p>
            <Link
              href="/contact"
              className="inline-flex items-center justify-center h-12 px-8 rounded-md bg-cyan-500 text-white font-medium hover:bg-cyan-600 transition-colors"
            >
              Voir nos offres d'emploi
            </Link>
          </div>
        </section>
      </main>
    </div>
  )
}
