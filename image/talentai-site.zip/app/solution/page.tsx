import Image from "next/image"
import Link from "next/link"
import FeatureCard from "@/components/feature-card"

export default function Solution() {
  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-16 md:py-24 bg-gradient-to-br from-[#0e3b5e] to-[#0e3b5e]/90 text-white">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Notre Solution PlurineurAI</h1>
              <p className="text-xl text-white/80 mb-8">
                Une plateforme RH complète qui utilise l'intelligence artificielle pour transformer votre processus de
                recrutement.
              </p>
              <p className="text-lg text-cyan-400 font-medium italic">"Recruter plus vite, plus humain"</p>
            </div>
          </div>
        </section>

        {/* Figma UI Mockup Section */}
        <section className="py-20">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <div className="inline-block px-4 py-1 bg-cyan-100 text-cyan-800 rounded-full text-sm font-medium mb-4">
                  Interface intuitive
                </div>
                <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-6">
                  Une expérience utilisateur optimale
                </h2>
                <p className="text-lg text-gray-600 mb-6">
                  PlurineurAI transforme la gestion des talents avec une intelligence artificielle prédictive et
                  éthique, permettant aux entreprises d'identifier, recruter et fidéliser les meilleurs profils avant
                  même que le besoin ne devienne urgent.
                </p>
                <ul className="space-y-4 mb-6">
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-cyan-600"
                      >
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Recrutement automatisé</strong> pour réduire de 70% le temps
                      consacré au tri des CV
                    </p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-cyan-600"
                      >
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Matching de talents</strong> grâce à notre algorithme avancé
                      qui associe rapidement les candidats aux opportunités adéquates
                    </p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-cyan-600"
                      >
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Analyse prédictive RH</strong> pour anticiper vos besoins en
                      talents via une analyse de données avancée
                    </p>
                  </li>
                </ul>
              </div>
              <div className="relative">
                <div className="absolute -top-4 -left-4 w-full h-full bg-[#0e3b5e]/10 rounded-lg"></div>
                <div className="relative bg-white p-4 rounded-lg shadow-xl border border-gray-200">
                  <div className="flex items-center gap-2 border-b border-gray-200 pb-3 mb-4">
                    <div className="flex gap-1.5">
                      <div className="w-3 h-3 rounded-full bg-red-500"></div>
                      <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                      <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    </div>
                    <div className="text-xs text-gray-500 bg-gray-100 rounded-md px-2 py-1 flex-1 text-center">
                      PlurineurAI - Dashboard
                    </div>
                  </div>
                  <Image
                    src="/images/figma-ui-mockup.png"
                    alt="Interface PlurineurAI"
                    width={600}
                    height={400}
                    className="rounded-md shadow-md border border-gray-200"
                  />
                  <div className="mt-4 grid grid-cols-3 gap-2">
                    <div className="bg-gray-100 p-2 rounded-md">
                      <div className="h-2 w-20 bg-[#0e3b5e]/60 rounded-full mb-2"></div>
                      <div className="h-2 w-16 bg-[#0e3b5e]/40 rounded-full"></div>
                    </div>
                    <div className="bg-gray-100 p-2 rounded-md">
                      <div className="h-2 w-20 bg-[#0e3b5e]/60 rounded-full mb-2"></div>
                      <div className="h-2 w-16 bg-[#0e3b5e]/40 rounded-full"></div>
                    </div>
                    <div className="bg-gray-100 p-2 rounded-md">
                      <div className="h-2 w-20 bg-[#0e3b5e]/60 rounded-full mb-2"></div>
                      <div className="h-2 w-16 bg-[#0e3b5e]/40 rounded-full"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Introduction Section */}
        <section className="py-20 bg-gray-50">
          <div className="container">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-6 text-center">Notre approche</h2>
              <div className="prose prose-lg max-w-none text-gray-600">
                <p className="mb-4">
                  Dans un monde professionnel en perpétuelle mutation, où l'acquisition et la rétention des talents sont
                  devenues des enjeux majeurs, PlurineurAI s'impose comme une solution incontournable pour les
                  entreprises souhaitant moderniser leur gestion des ressources humaines. Grâce à une intelligence
                  artificielle éthique et performante, notre plateforme ne se contente pas de simplifier le recrutement
                  : elle révolutionne la manière dont les entreprises identifient, évaluent et intègrent leurs talents.
                </p>
                <p className="mb-4">
                  Avec PlurineurAI, nous proposons une approche novatrice qui repose sur l'exploitation du Big Data, du
                  Machine Learning et de l'analyse comportementale. Notre technologie permet d'anticiper les besoins en
                  compétences, d'identifier les candidats à fort potentiel et d'optimiser l'ensemble du cycle RH, de la
                  présélection des profils à l'intégration des nouveaux employés. Fini les recrutements basés sur
                  l'intuition : notre solution fournit des analyses prédictives fiables et objectives, garantissant des
                  décisions plus rapides, inclusives et alignées sur la stratégie globale de l'entreprise.
                </p>
                <p>
                  Loin d'être un simple logiciel RH, PlurineurAI est un véritable partenaire stratégique. Il aide les
                  startups en pleine croissance à structurer efficacement leur acquisition de talents et accompagne les
                  grandes entreprises dans l'optimisation de leurs ressources humaines. Grâce à une interface intuitive
                  et un moteur d'IA évolutif, PlurineurAI s'adapte aux besoins spécifiques de chaque organisation, tout
                  en respectant des principes éthiques stricts pour limiter les biais et promouvoir une diversité
                  équitable et inclusive dans les processus de recrutement.
                </p>
              </div>
              <div className="text-center mt-8">
                <p className="text-xl font-bold text-cyan-600">PlurineurAI : anticipez, recrutez, innovez !</p>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-4">Fonctionnalités clés</h2>
              <p className="text-lg text-gray-600">
                Découvrez les outils puissants qui font de PlurineurAI la solution idéale pour votre recrutement.
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <FeatureCard
                icon="matching"
                title="Matching de talents"
                description="Algorithme avancé qui trouve les candidats parfaitement adaptés à vos besoins spécifiques."
              />
              <FeatureCard
                icon="predictive"
                title="IA prédictive RH"
                description="Anticipez les besoins en recrutement et optimisez la gestion des talents grâce à nos modèles prédictifs."
              />
              <FeatureCard
                icon="unbiased"
                title="Recrutement sans biais"
                description="Éliminez les préjugés inconscients du processus de recrutement pour une sélection plus équitable."
              />
              <FeatureCard
                icon="experience"
                title="Expérience candidat"
                description="Offrez un parcours fluide et personnalisé à chaque candidat pour valoriser votre marque employeur."
              />
            </div>
          </div>
        </section>

        {/* Figma Prototype Section */}
        <section className="py-20 bg-gray-50">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-4">Notre interface utilisateur</h2>
              <p className="text-lg text-gray-600">
                Découvrez notre interface intuitive conçue pour simplifier votre processus de recrutement
              </p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200 max-w-5xl mx-auto">
              <div className="aspect-w-16 aspect-h-9 relative">
                <iframe
                  src="https://www.figma.com/embed?embed_host=share&url=https%3A%2F%2Fwww.figma.com%2Fproto%2FcHtE227sdV4EoZoWO9oGLb%2Fappli-recutemant-IA%3Fnode-id%3D4-133%26starting-point-node-id%3D4%253A133%26t%3DFU92InWXcnYnmYsz-1"
                  allowFullScreen
                  className="w-full h-[600px]"
                ></iframe>
              </div>
              <div className="mt-6 text-center">
                <p className="text-gray-600 italic">Cliquez sur les éléments pour naviguer dans le prototype</p>
              </div>
            </div>
          </div>
        </section>

        {/* Platform Architecture */}
        <section className="py-20">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-4">Architecture de la plateforme</h2>
              <p className="text-lg text-gray-600">
                Une solution complète et modulaire qui s'adapte à vos besoins spécifiques
              </p>
            </div>
            <div className="relative bg-white p-6 md:p-10 rounded-xl shadow-lg border border-gray-200 overflow-hidden">
              <div className="absolute top-0 right-0 bg-cyan-500/10 w-64 h-64 rounded-full -mr-32 -mt-32"></div>
              <div className="absolute bottom-0 left-0 bg-[#0e3b5e]/10 w-64 h-64 rounded-full -ml-32 -mb-32"></div>

              <div className="relative">
                <Image
                  src="/images/platform-architecture.png"
                  alt="Architecture PlurineurAI"
                  width={1200}
                  height={600}
                  className="mx-auto"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Case Study - Plurielles */}
        <section className="py-20 bg-gray-50">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="relative h-[400px] rounded-lg overflow-hidden shadow-xl">
                <Image src="/images/plurielles-case.jpg" alt="Cas Plurielles" fill className="object-cover" />
              </div>
              <div>
                <div className="inline-block px-4 py-1 bg-cyan-100 text-cyan-800 rounded-full text-sm font-medium mb-4">
                  Cas client
                </div>
                <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-6">Plurielles</h2>
                <p className="text-lg text-gray-600 mb-6">
                  Plurielles, une entreprise dédiée à la promotion de la diversité en entreprise, a utilisé PlurineurAI
                  pour transformer son processus de recrutement et atteindre ses objectifs d'inclusion.
                </p>
                <ul className="space-y-4 mb-6">
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-cyan-600"
                      >
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Augmentation de 40%</strong> de la diversité des profils
                      recrutés
                    </p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-cyan-600"
                      >
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Réduction de 60%</strong> du temps consacré au tri des CV
                    </p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-cyan-600"
                      >
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Amélioration de 35%</strong> de la satisfaction des candidats
                    </p>
                  </li>
                </ul>
                <div className="p-4 bg-white rounded-lg shadow-md border-l-4 border-cyan-500">
                  <p className="text-gray-700 italic">
                    "PlurineurAI nous a permis de révolutionner notre approche du recrutement. Nous avons pu identifier
                    des talents que nous n'aurions jamais découverts avec nos méthodes traditionnelles."
                  </p>
                  <p className="text-right mt-2 font-medium text-[#0e3b5e]">
                    — Alexandre Maury, Directeur Général, Plurielles
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* How It Works */}
        <section className="py-20">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-4">Comment ça fonctionne</h2>
              <p className="text-lg text-gray-600">
                PlurineurAI simplifie votre processus de recrutement en quelques étapes simples.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="relative">
                <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow text-center">
                  <div className="h-16 w-16 rounded-full bg-cyan-100 flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-cyan-600">1</span>
                  </div>
                  <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Définissez vos besoins</h3>
                  <p className="text-gray-600">
                    Précisez les compétences, l'expérience et les qualités recherchées pour le poste à pourvoir.
                  </p>
                </div>
                <div className="hidden md:block absolute top-1/2 right-0 transform translate-x-1/2 -translate-y-1/2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="40"
                    height="40"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-cyan-400"
                  >
                    <path d="M5 12h14" />
                    <path d="m12 5 7 7-7 7" />
                  </svg>
                </div>
              </div>
              <div className="relative">
                <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow text-center">
                  <div className="h-16 w-16 rounded-full bg-cyan-100 flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-cyan-600">2</span>
                  </div>
                  <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">L'IA analyse les profils</h3>
                  <p className="text-gray-600">
                    Notre algorithme évalue les candidatures et identifie les meilleurs profils correspondant à vos
                    critères.
                  </p>
                </div>
                <div className="hidden md:block absolute top-1/2 right-0 transform translate-x-1/2 -translate-y-1/2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="40"
                    height="40"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-cyan-400"
                  >
                    <path d="M5 12h14" />
                    <path d="m12 5 7 7-7 7" />
                  </svg>
                </div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow text-center">
                <div className="h-16 w-16 rounded-full bg-cyan-100 flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-cyan-600">3</span>
                </div>
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Recrutez efficacement</h3>
                <p className="text-gray-600">
                  Concentrez-vous sur les entretiens avec les candidats présélectionnés et prenez des décisions
                  éclairées.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Technology Section */}
        <section className="py-20 bg-gray-50">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-6">Notre technologie</h2>
                <p className="text-lg text-gray-600 mb-6">
                  PlurineurAI utilise des algorithmes d'apprentissage profond et de traitement du langage naturel pour
                  analyser les profils des candidats et les offres d'emploi.
                </p>
                <ul className="space-y-4">
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-cyan-600"
                      >
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Analyse sémantique avancée</strong> pour comprendre le contexte
                      et les nuances des compétences.
                    </p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-cyan-600"
                      >
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Algorithmes de matching</strong> qui s'améliorent
                      continuellement grâce au machine learning.
                    </p>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-cyan-100 flex items-center justify-center mt-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-cyan-600"
                      >
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                    </div>
                    <p className="text-gray-700">
                      <strong className="text-[#0e3b5e]">Détection et élimination des biais</strong> pour un recrutement
                      plus équitable et diversifié.
                    </p>
                  </li>
                </ul>
              </div>
              <div className="relative h-[400px] rounded-lg overflow-hidden shadow-xl">
                <Image src="/images/technology.jpg" alt="Notre technologie" fill className="object-cover" />
              </div>
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section className="py-20">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-4">Nos offres</h2>
              <p className="text-lg text-gray-600">
                Des solutions adaptées à toutes les tailles d'entreprise, de la startup à la multinationale.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-100">
                <h3 className="text-2xl font-bold text-[#0e3b5e] mb-2">Starter</h3>
                <p className="text-gray-600 mb-6">Idéal pour les petites entreprises</p>
                <div className="text-4xl font-bold text-[#0e3b5e] mb-6">
                  299€ <span className="text-lg font-normal text-gray-500">/mois</span>
                </div>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center gap-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-green-500"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    <span className="text-gray-700">Jusqu'à 10 recrutements/mois</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-green-500"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    <span className="text-gray-700">Matching de talents</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-green-500"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    <span className="text-gray-700">Support par email</span>
                  </li>
                </ul>
                <Link
                  href="/contact"
                  className="block w-full py-3 px-4 bg-[#0e3b5e] text-white text-center rounded-md font-medium hover:bg-[#0e3b5e]/90 transition-colors"
                >
                  Commencer
                </Link>
              </div>
              <div className="bg-white p-8 rounded-lg shadow-xl hover:shadow-2xl transition-shadow border-2 border-cyan-500 relative">
                <div className="absolute top-0 right-0 bg-cyan-500 text-white px-4 py-1 text-sm font-medium rounded-bl-lg rounded-tr-lg">
                  Populaire
                </div>
                <h3 className="text-2xl font-bold text-[#0e3b5e] mb-2">Business</h3>
                <p className="text-gray-600 mb-6">Pour les entreprises en croissance</p>
                <div className="text-4xl font-bold text-[#0e3b5e] mb-6">
                  699€ <span className="text-lg font-normal text-gray-500">/mois</span>
                </div>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center gap-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-green-500"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    <span className="text-gray-700">Jusqu'à 30 recrutements/mois</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-green-500"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    <span className="text-gray-700">Toutes les fonctionnalités</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-green-500"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    <span className="text-gray-700">Support prioritaire</span>
                  </li>
                </ul>
                <Link
                  href="/contact"
                  className="block w-full py-3 px-4 bg-cyan-500 text-white text-center rounded-md font-medium hover:bg-cyan-600 transition-colors"
                >
                  Commencer
                </Link>
              </div>
              <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-100">
                <h3 className="text-2xl font-bold text-[#0e3b5e] mb-2">Enterprise</h3>
                <p className="text-gray-600 mb-6">Pour les grandes organisations</p>
                <div className="text-4xl font-bold text-[#0e3b5e] mb-6">Sur mesure</div>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-center gap-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-green-500"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    <span className="text-gray-700">Volume illimité</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-green-500"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    <span className="text-gray-700">Fonctionnalités personnalisées</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-green-500"
                    >
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    <span className="text-gray-700">Gestionnaire de compte dédié</span>
                  </li>
                </ul>
                <Link
                  href="/contact"
                  className="block w-full py-3 px-4 bg-[#0e3b5e] text-white text-center rounded-md font-medium hover:bg-[#0e3b5e]/90 transition-colors"
                >
                  Nous contacter
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-br from-[#0e3b5e] to-[#0e3b5e]/90 text-white">
          <div className="container text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Prêt à transformer votre recrutement ?</h2>
            <p className="text-xl text-white/80 max-w-2xl mx-auto mb-8">
              Demandez une démonstration personnalisée de PlurineurAI et découvrez comment notre solution peut répondre
              à vos besoins.
            </p>
            <Link
              href="/contact"
              className="inline-flex items-center justify-center h-12 px-8 rounded-md bg-cyan-500 text-white font-medium hover:bg-cyan-600 transition-colors"
            >
              Demander une démo
            </Link>
          </div>
        </section>
      </main>
    </div>
  )
}
