import { Linkedin, Instagram } from "lucide-react"
import ContactForm from "@/components/contact-form"

export default function Contact() {
  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-16 md:py-24 bg-gradient-to-br from-[#0e3b5e] to-[#0e3b5e]/90 text-white">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Contactez-nous</h1>
              <p className="text-xl text-white/80 mb-8">
                Vous souhaitez en savoir plus sur PlurineurAI ? Laissez-nous un message et nous vous répondrons dans les
                plus brefs délais.
              </p>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-20">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-start">
              <div>
                <h2 className="text-3xl font-bold text-[#0e3b5e] mb-6">Nous contacter</h2>
                <p className="text-lg text-gray-600 mb-8">
                  Que vous soyez intéressé par une démonstration, que vous ayez des questions sur nos offres ou que vous
                  souhaitiez simplement en savoir plus sur TalentAI, notre équipe est là pour vous répondre.
                </p>
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 rounded-full bg-cyan-100 flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-cyan-600"
                      >
                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-[#0e3b5e]">Téléphone</h3>
                      <p className="text-gray-600">+33 1 23 45 67 89</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 rounded-full bg-cyan-100 flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-cyan-600"
                      >
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                        <polyline points="22,6 12,13 2,6" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-[#0e3b5e]">Email</h3>
                      <p className="text-gray-600">contact@talentai.fr</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 rounded-full bg-cyan-100 flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-cyan-600"
                      >
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                        <circle cx="12" cy="10" r="3" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-[#0e3b5e]">Adresse</h3>
                      <p className="text-gray-600">123 Avenue de l'Innovation, 75008 Paris, France</p>
                    </div>
                  </div>
                </div>
                <div className="mt-8">
                  <h3 className="font-semibold text-[#0e3b5e] mb-4">Suivez-nous</h3>
                  <div className="flex gap-4">
                    <a
                      href="https://www.linkedin.com/company/talent-ai-2025"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="h-12 w-12 rounded-full bg-[#0e3b5e] flex items-center justify-center text-white hover:bg-[#0e3b5e]/80 transition-colors"
                    >
                      <Linkedin className="h-6 w-6" />
                    </a>
                    <a
                      href="https://www.instagram.com/talentai2025/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="h-12 w-12 rounded-full bg-[#0e3b5e] flex items-center justify-center text-white hover:bg-[#0e3b5e]/80 transition-colors"
                    >
                      <Instagram className="h-6 w-6" />
                    </a>
                  </div>
                </div>
              </div>
              <div className="bg-white p-8 rounded-lg shadow-lg">
                <h2 className="text-2xl font-bold text-[#0e3b5e] mb-6">Envoyez-nous un message</h2>
                <ContactForm />
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-20 bg-gray-50">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-4">Questions fréquentes</h2>
              <p className="text-lg text-gray-600">Vous avez des questions ? Nous avons les réponses.</p>
            </div>
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Comment fonctionne PlurineurAI ?</h3>
                <p className="text-gray-600">
                  PlurineurAI utilise des algorithmes d'intelligence artificielle pour analyser les profils des
                  candidats et les offres d'emploi afin de trouver les meilleures correspondances. Notre technologie
                  prend en compte non seulement les compétences techniques, mais aussi les soft skills et la culture
                  d'entreprise.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">Combien de temps dure l'implémentation ?</h3>
                <p className="text-gray-600">
                  L'implémentation de PlurineurAI est rapide et simple. En général, notre solution est opérationnelle en
                  moins d'une semaine. Notre équipe vous accompagne tout au long du processus pour assurer une
                  transition en douceur.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">
                  PlurineurAI s'intègre-t-il à nos outils existants ?
                </h3>
                <p className="text-gray-600">
                  Oui, PlurineurAI s'intègre facilement avec la plupart des ATS (Applicant Tracking Systems) et des SIRH
                  du marché. Nous proposons également des API pour des intégrations personnalisées.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold text-[#0e3b5e] mb-2">
                  Comment garantissez-vous l'absence de biais ?
                </h3>
                <p className="text-gray-600">
                  Nous avons développé des algorithmes spécifiques pour détecter et éliminer les biais potentiels dans
                  le processus de recrutement. Notre système est régulièrement audité par des experts indépendants pour
                  garantir son équité.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Map Section */}
        <section className="py-20">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-[#0e3b5e] mb-4">Nous trouver</h2>
              <p className="text-lg text-gray-600">Venez nous rencontrer dans nos bureaux au cœur de Paris.</p>
            </div>
            <div className="h-[400px] rounded-lg overflow-hidden shadow-lg">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2624.142047342144!2d2.3002659156744847!3d48.87456857928886!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66fc4f8f3049b%3A0xcbb47407434935db!2sArc%20de%20Triomphe!5e0!3m2!1sfr!2sfr!4v1651234567890!5m2!1sfr!2sfr"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}
